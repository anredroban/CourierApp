<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHistorialsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('historials', function (Blueprint $table) {
            $table->id();
            
            $table->integer('tramite_id',)->nullable();
            $table->integer('numero_guia')->nullable();
            $table->integer('numero_lote')->nullable();
            $table->string('nombre_cliente')->nullable();
            $table->string('estado')->nullable();
            $table->string('fecha_registro')->nullable();
            $table->date('ciclo')->nullable();
            $table->datetime('fecha_para_entrega')->nullable();
            $table->integer('cedula_destinatario')->nullable();
            $table->string('nombre_destinatario')->nullable();
            $table->string('direccion_destinatario')->nullable();
            $table->string('ciudad_destino')->nullable();
            $table->string('telefono')->nullable();
            $table->string('id_tarjeta')->nullable();
            $table->datetime('fecha_entrega')->nullable();
            $table->string('recibido_por')->nullable();
            $table->datetime('fecha_excepcion')->nullable();
            $table->string('contenido')->nullable();
            $table->string('motivo_excepcion')->nullable();
            $table->string('mensajero_actual')->nullable();
            $table->integer('cantidad')->nullable();
            $table->string('id_venta')->nullable();
            $table->boolean('is_active')->nullable();
            $table->string('estado_id')->nullable();
            $table->string('subestado_id')->nullable();
            $table->string('usuario_id')->nullable();
            $table->datetime('fecha_gestion')->nullable();
           
            

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('historials');
    }
}
